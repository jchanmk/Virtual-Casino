import javax.swing.JComponent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.Font;
import java.util.Random;
import java.util.Scanner;
import java.lang.Thread;
import java.lang.InterruptedException;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class GraphicsComponentSlots extends JComponent     // Class
{		
   int frameW, frameH;
   int chosenOption;
   int playerOption1;
   int playerOption2;
   int playerOption3;
   int playerOption4;
   int z = 0, a = 1, b = 2, c = 3, d = 4, e = 5, f = 6, g = 7, h = 8, i = 9;
   int watermelon;
   int grapes = 10;
   int banana = 11;
   int cherry = 12;
   int lime = 13;
   int lemon = 14;
   int strawberry = 15;
   int orange = 16;
   int bells = 17;
   int wildcard = 18;
   Random r = new Random();
   String payout = "Payout:";
   String credits = "Select Number of Credits to Play:";
   String s3 = "  ";
   String s4 = "  ";
   String s5 = "  ";
   String s6 = "  ";
   String balance = "Credits: $";
   String s8 = "  ";
   String goodluck = "Goodluck!";
   String spin = "Spin Again!";
   String balanceString = "100";
   String sBankrupt1 = "  ";
   String sBankrupt = "Bankrupt!";
   int [] values = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
                    0, 3, 6, 9, 12, 15, 18, 21, 24, 27};

   int gamblerCredits;
   int credits = Integer.parseInt(creditsString); 
   boolean pulllever = true;
   boolean enough = true;
   
   public GraphicsComponentSlots(int fW, int fH, ImageIcon[] slots)
      {
      images = slots;
      frameW = fW;
      frameH = fH;
     // Graphics g3 = (Graphics2D) g;
      }
      
      public void update()  
      {
         Scanner in = new Scanner(System.in);
         
         do 
         {
            s3 = s5;
            s4 = s5;
            s6 = s5;
            s8 = s5;
            int gamblerCredits = 0;
            repaint();

            Object [] MainOpts = {"Play Slots", "Quit"};     //Main Menu
            chosenOption = JOptionPane.showOptionDialog(null, "Click an option", 
                 "Slots Options", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                  null, MainOpts, MainOpts[0]);

         if(chosenOption == 1)
         {
            break;
         }
               
         String wager1 = JOptionPane.showInputDialog("Bet your number of Credits you choose:");
         wager = Integer.parseInt(wager1); 
         if(wager > balance)
         {
            JOptionPane.showMessageDialog(null, "Insufficient Credits!", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
         }
         else if(wager < 2)
         {
         JOptionPane.showMessageDialog(null, "Minimum bet is 1 Credit!", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
         }
         
         
 
         ////////////////////////////////Actually Playing//////////////////////////////////////////////
         ImageIcon w = new ImageIcon("watermelon.png");
         ImageIcon g = new ImageIcon("grapes.png");
         ImageIcon b = new ImageIcon("banana.png");
         ImageIcon c = new ImageIcon("cherry.png");
         ImageIcon lim = new ImageIcon("lime.png");
         ImageIcon lem = new ImageIcon("lemon.png");
         ImageIcon s = new ImageIcon("strawberry.png");
         ImageIcon o = new ImageIcon("orange.png");
         ImageIcon b = new ImageIcon("bells.png");
         ImageIcon wild = new ImageIcon("wildcard.png");
         
         ImageIcon one = new ImageIcon("numberone.png");
         ImageIcon two = new ImageIcon("numbertwo.png");
         ImageIcon three = new ImageIcon("numberthree.png");
         ImageIcon four = new ImageIcon("numberfour.png");
         ImageIcon five = new ImageIcon("numberfive.png");
         ImageIcon six = new ImageIcon("numbersix.png");
         ImageIcon seven = new ImageIcon("numberseven.png");
         ImageIcon eight = new ImageIcon("numbereight.png");
         ImageIcon nine = new ImageIcon("numbernine.png");
         
         Combos watermelon = new Combos (w);
         Combos grapes = new Combos (g);
         Combos banana = new Combos (b);
         Combos cherry = new Combos (c);
         Combos lime = new Combos (lim);
         Combos lemon = new Combos (lem);
         Combos strawberry = new Combos (s);
         Combos organge = new Combos (o);
         Combos bells = new Combos (b);
         Combos wildcard = new Combos (wild);
         
         Combos numberone = new Combos (one);
         Combos numbertwo = new Combos (two);
         Combos numberthree = new Combos (three);
         Combos numberfour = new Combos (four);
         Combos numberfive = new Combos (five);
         Combos numbersix = new Combos (six);
         Combos numberseven = new Combos (seven);
         Combos numbereight = new Combos (eight);
         Combos numbernine = new Combos (nine);
         
         ArrayList <Combos> combosList = new ArrayList <Integer> ();
         combosList.add(numberone); 
         combosList.add(numbertwo); 
         combosList.add(numberthree); 
         combosList.add(numberfour); 
         combosList.add(numberfive); 
         combosList.add(numbersix); 
         combosList.add(numberseven); 
         combosList.add(numbereight); 
         combosList.add(numbernine); 
    
         combosList.add(watermelon); 
         combosList.add(grapes); 
         combosList.add(banana); 
         combosList.add(cherry); 
         combosList.add(lime); 
         combosList.add(lemon); 
         combosList.add(strawberry); 
         combosList.add(orange); 
         combosList.add(bells); 
         combosList.add(wildcard);    
         
         do
         {
            if (pulllever)
              {
                for (i = 0; i < 3; i++)
                  for (j=0; j < 21; j++)
                     {
                        int firstimage = combosList.getImage(r.nextInt(j));
                        int secondimage = combosList.getImage(r.nextInt(j));
                        int thirdimage = combosList.getImage(r.nextInt(j));        
                        int combo = firstimage + secondimage + thirdimage;
                       
                        if (firstimage = watermelon && secondimage = grapes && thirdimage = banana)  
                        {
                           combo = 0;
                           credits -= wager; 
                           
                           Object [] KeepGoingOpts = {"Would you like to Keep going?", "Quit"};     //Main Menu
                           decision = JOptionPane.showOptionDialog(null, "Click an option", 
                           "Decision Time", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                           null, KeepGoingOpts, KeepGoingOpts[0]);
                                                     
                           if (decision == 1)
                           {
                              break;
                           }
                        }
                           
                        if (firstimage = watermelon && secondimage = grapes && thirdimage = grapes)  
                        {
                           combo = 0;
                           credits -= wager; 
                           
                        }
                        
                        if (firstimage = watermelon && secondimage = grapes && thirdimage = watermelon)  
                        {
                           combo = 1;
                           credits += wager; 
                           repaint();
                        }
                        
                        if (firstimage = watermelon && secondimage = grapes && thirdimage = lemon )  
                        {
                           combo = 0;
                           credits -= wager; 
                           repaint();
                        }

                     }
                     
                              
               
               
               
               }
         
             
         
         
         
         
         
         }
         }         
       }
}