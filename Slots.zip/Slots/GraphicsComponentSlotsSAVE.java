   import javax.swing.JComponent;
   import java.awt.Graphics;
  import java.awt.Graphics2D;
  import java.awt.Color;
  import java.awt.BasicStroke;
  import java.awt.Font;
  import java.util.Random;
  import java.util.Scanner;
   import java.lang.Thread;
  import java.lang.InterruptedException;
  import javax.swing.JOptionPane;
  import java.util.ArrayList;
  import javax.swing.ImageIcon;
  import javax.swing.JButton;
  import javax.swing.JFrame;
  import javax.swing.JLabel;
  import javax.swing.JPanel;
  import java.awt.Dimension;
  import java.awt.GridLayout;
 import java.awt.BorderLayout;
 
  public class GraphicsComponentSlotsSAVE extends JComponent     // Class
  {    
     int frameW, frameH;
    int chosenOption;
     int playerOption1;
     int playerOption2;
     int playerOption3;
     int playerOption4;
    int z = 0, a = 19, b = 2, c = 3, d = 4, e = 5, f = 6, g = 7, h = 8, i = 9;
    int watermelon=10 ;
    int grapes = 10;
    int banana = 10;
    int cherry = 11;
    int lime = 13;
    int lemon = 14;
    int strawberry = 15;
     int orange = 16;
     int bells = 17;
     int wildcard = 18;
     ImageIcon[] combos;
    Random r = new Random();
    String payout = "Payout:";
    String bet = "Select Number of Credits to Play:";
    String s3 = "  ";
     String s4 = "  ";
 47    String s5 = "  ";
 48    String s6 = "  ";
 49    String balanceWord = "Credits: $";
 50    String s8 = "  ";
 51    int balance = 100;
 52    String sBankrupt1 = "  ";
 53    String sBankrupt = "Bankrupt!";
 54    //int [] values = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
 55 //
 56    int values = 20;
 57    int gamblerCredits;
 58    //int amount = Integer.parseInt(balanceString);
 59    int combo = 0;
 60    boolean playing = false;
 61    boolean enough = false;
 62    boolean settingup = true;
 63    boolean notvisible = true;
 64    boolean visible = false;
 65    ImageIcon firstimage;
 66    ImageIcon secondimage;
 67    ImageIcon thirdimage;
 68    int firstrandom = r.nextInt(18); // how to get a random image from the arrayList without a specific one
 69    int secondrandom = r.nextInt(18);
 70    int thirdrandom = r.nextInt(18);
 71    private static JPanel labelPanel = new JPanel();
 72    private static JFrame buttonFrame = new JFrame("Button Frame");
 73   
 74   
 75    public GraphicsComponentSlotsV2 (int fW, int fH, ImageIcon[] slots)
 76       {
 77       combos = slots;
 78       frameW = fW;
 79       frameH = fH;
 80      // Graphics g3 = (Graphics2D) g;
 81       }
 82      
 83       public void update() throws InterruptedException
 84       {
 85         
 86         
 87          /*ImageIcon [] combos = new ImageIcon [20];
 88          combos [0] = new ImageIcon("watermelon.png");
 89          combos [1] = new ImageIcon("grapes.png");
 90          combos [2] = new ImageIcon("banana.png");
 91          combos [3] = new ImageIcon("cherry.png");
 92          combos [4] = new ImageIcon("lime.png");
 93          combos [5] = new ImageIcon("lemon.png");
 94          combos [6] = new ImageIcon("strawberry.png");
 95          combos [7] = new ImageIcon("orange.png");
 96          combos [8] = new ImageIcon("bells.png");
 97          combos [9] = new ImageIcon("wildcard.png");
 98                  
 99          combos [10] = new ImageIcon("numberone.png");
100          combos [11] = new ImageIcon("numbertwo.png");
101          combos [12] = new ImageIcon("numberthree.png");
102          combos [13] = new ImageIcon("numberfour.png");
103          combos [14] = new ImageIcon("numberfive.png");
104          combos [15] = new ImageIcon("numbersix.png");
105          combos [16] = new ImageIcon("numberseven.png");
106          combos [17] = new ImageIcon("numbereight.png");
107          combos [18] = new ImageIcon("numbernine.png");
108          combos [19] = new ImageIcon ("nothing.jpg");*/
109
110          Scanner in = new Scanner(System.in);
111          gamblerCredits = 100;
112         
113         
114          while (settingup)
115          {
116            
117             //repaint();
118
119             Object [] MainOpts = {"Play Slots", "Quit"};     //Main Menu
120             chosenOption = JOptionPane.showOptionDialog(null, "Click an option",
121                  "Slots Options", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
122                   null, MainOpts, MainOpts[0]);
123            
124             if(chosenOption == 1)
125             {
126                break;
127             }
128            
129          
130             //if (chosenOption == 0)
131             //{
132                String wager1 = JOptionPane.showInputDialog("Bet your number of Credits you choose:");
133                int wager = Integer.parseInt(wager1);
134                System.out.println(wager);
135               
136                notvisible = false;
137                
138              
139                 
140                if(wager > balance)
141                   {
142                     
143                      JOptionPane.showMessageDialog(null, "Insufficient Credits!", "Error", JOptionPane.ERROR_MESSAGE);
144                      continue;
145                   }
146               
147               
148               else if(wager < 2)
149                   {
150                     
151                      JOptionPane.showMessageDialog(null, "Minimum bet is 2 Credits!", "Error", JOptionPane.ERROR_MESSAGE);
152                      continue;
153                   }
154                 
155                //if ((wager >=2) && (wager <= gamblerCredits))
156                  // {
157                      //playing = true;
158                      //do
159                      //{
160                         for(int i = 1; i < 15; i++){
161                         try{Thread.sleep(30*i);}
162                         catch(InterruptedException e) {}
163                         firstrandom = r.nextInt(19) ; // how to get a random image from the arrayList without a specific one
164                         secondrandom = r.nextInt(19);
165                         thirdrandom = r.nextInt(19);
166                         repaint();
167                         }
168                         JLabel label1 = new JLabel("Slot 1", combos[firstrandom],JLabel.CENTER);
169                         JLabel label2 = new JLabel("Slot 2", combos[secondrandom],JLabel.CENTER);
170                         JLabel label3 = new JLabel("Slot 3", combos[thirdrandom],JLabel.CENTER);
171
172                      //} while (playing);
173                                                                                          //for (int i = 0; i < 100; i++)
174                               //{
175                                 // for (int j=0; j < 19; j++)
176                                  //{
177                                            
178                                    
179                                     // how to I gather firstimage, secondimage, and thirdimage and print them all to the screen/repaint?
180                                    
181                                     //switch (values)
182                                     //{
183                                    
184                                        //case 1 :
185                                   
186                                     if ((firstrandom  == secondrandom) && (firstrandom == thirdrandom))
187                                           balance += wager*3;
188                                             
189                                        //case 2 :
190                                     if ((firstrandom  != secondrandom) && (firstrandom != thirdrandom))
191                                           balance = balance - wager;
192                                    
193                                     if ((firstrandom  == secondrandom) || (firstrandom == thirdrandom)) 
194                                     firstimage = combos[firstrandom];
195                                     secondimage = combos[secondrandom];
196                                     thirdimage = combos[thirdrandom];  
197                                    
198                                     System.out.println(balance);
199                            
200                                     /* case 3 :
201                                    
202                                    
203                                         if ((firstrandom <= 9) && (secondrandom >= 9))
204                                           amount += 0;
205                                       
206                                        //case 4 :
207                                         if ((firstrandom > 9) && (secondrandom <= 9))
208                                           amount += 0;
209                                          
210                                        //case 5 :
211                                         if ((firstrandom < 9) && (secondrandom >= 9))
212                                           amount += 0;
213                                      
214                                        //case 6 :
215                                         if ((firstrandom >= 9) &&  (secondrandom > 9))
216                                           amount += 0;
217                                       
218                                        //case 7 :
219                                         if ((firstrandom <= 9) && (secondrandom < 9))
220                                           amount += 0;
221                                       
222                                        //case 8 :
223                                         if ((firstrandom > 9) && (secondrandom >= 9))
224                                           amount += 0;
225                                       
226                                        //case 9 :
227                                         if ((firstrandom > 9) && (secondrandom >= 9))
228                                           amount += 0;
229         
230                                        //default: amount += 0;
231                                     }
232      
233                                 //}
234                                 
235                                //}
236                            */   
237                           
238                   if (balance == 0)
239                   {
240                    
241                   sBankrupt1 = sBankrupt;
242                   repaint();
243                   JOptionPane.showMessageDialog(null, "Out of credits! Know when to quit!", "Error", JOptionPane.ERROR_MESSAGE);
244                   break;
245                   }    
246                   //}
247               
248                } //while loop end
249              
250              
251         
252                //case 3:
253                  /* */
254                             
255                 
256                   
257               //}
258          
259       }
260    
261              ////////////////////////////////Actually Playing//////////////////////////////////////////////
262                              
263       
264                            /* if (firstimage = combos [w)  //&& secondimage = grapes && thirdimage = banana) 
265                            {
266                               combo = 0;
267                               credits += wager;
268                              
269                               Object [] KeepGoingOpts = {"Would you like to Keep going?", "Quit"};     //Main Menu
270                              
271                               optionOption = JOptionPane.showOptionDialog(null, "Click an option",
272                               "Decision Time", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
273                               null, KeepGoingOpts, KeepGoingOpts[0]);
274                              
275                                                        
276                               if (optionOption == 1)
277                               {
278                                  break;
279                               }
280                            }
281                              
282                           if (firstimage = watermelon && secondimage = grapes && thirdimage = grapes) 
283                            {
284                               combo = 0;
285                               credits += wager;
286                              
287                            }
288                           
289                            if (firstimage = watermelon && secondimage = grapes && thirdimage = watermelon) 
290                            {
291                               combo = 1;
292                               credits += wager;
293                               repaint();
294                            }
295                           
296                            if (firstimage = watermelon.getImage(9) && secondimage = grapes.getImage(10) && thirdimage = banana.getImage(12))
297                            {
298                               combo = 0;
299                               credits += wager;
300                               repaint();
301                            }*/
302                       
303                       
304                     
305              //}   
306            
307            
308         
309        
310        
311       public void paintComponent( Graphics g )    // Method: paintComponent
312       {
313          //background
314          Graphics g2 = (Graphics2D) g;
315          ImageIcon bg = new ImageIcon("slotsmachine - NEW.png");
316          bg.setImage(bg.getImage().getScaledInstance(1000, 1000, 0));
317          bg.paintIcon(this, g2, 0, -100);
318      
319      
320       //End messages
321       Graphics2D g13 = (Graphics2D) g;               //win message
322       Font f1 = new Font ("serif", Font.BOLD, 70);
323       g13.setColor(Color.WHITE);
324       g13.setFont(f1); 
325       g13.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT,
326                                            BasicStroke.JOIN_BEVEL));                                                                       
327       g13.drawString(s3, 50,100);
328      
329      
330       Graphics2D g14 = (Graphics2D) g;               //lose message
331       g14.setColor(Color.WHITE);
332       g14.setFont(f1); 
333       g14.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT,
334                                            BasicStroke.JOIN_BEVEL));                                                                       
335       g14.drawString(s4, 50,100);
336      
337       Font f3 = new Font ("serif", Font.BOLD, 30);
338       Graphics2D g18 = (Graphics2D) g;               //Balance number message
339       g18.setColor(Color.WHITE);
340       g18.setFont(f3); 
341       g18.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT,
342                                            BasicStroke.JOIN_BEVEL));                                                                       
343       g18.drawString(Integer.toString(balance) , 170, 600);
344      
345       Graphics2D g19 = (Graphics2D) g;               //Balance word message
346       g19.setColor(Color.WHITE);
347       g19.setFont(f3); 
348       g19.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT,
349                                            BasicStroke.JOIN_BEVEL));                                                                       
350       g19.drawString(balanceWord , 30, 600);
351      
352                                                                       
353      
354       Graphics2D g21 = (Graphics2D) g;               //Bankrupt message
355       g21.setColor(Color.GREEN);
356       g21.setFont(f1); 
357       g21.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT,
358                                            BasicStroke.JOIN_BEVEL));                                                                       
359       g21.drawString(sBankrupt1, 50, 200);
360      
361             
362       //Player Option deal
363      
364                 /*if (notvisible)
365             { 
366             
367                Graphics g7 = (Graphics2D) g;
368                ImageIcon positionone = combos [19];
369                positionone.setImage(positionone.getImage().getScaledInstance(70, 90, 0));
370                positionone.paintIcon(this, g7, 200, 420); 
371                
372                Graphics g8 = (Graphics2D) g;
373                ImageIcon positiontwo = combos [19];
374                positiontwo.setImage(positiontwo.getImage().getScaledInstance(70, 90, 0));
375                positiontwo.paintIcon(this, g8, 400, 420); 
376                
377                Graphics g9 = (Graphics2D) g;
378                ImageIcon positionthree = combos [19];
379                positionthree.setImage(positionthree.getImage().getScaledInstance(70, 90, 0));
380                positionthree.paintIcon(this, g9, 600, 420);
381               
382
383             */
384               
385          Graphics g10 = (Graphics2D) g;
386          ImageIcon visiblepositionone = combos [firstrandom];
387          visiblepositionone.setImage(visiblepositionone.getImage().getScaledInstance(70, 90, 0));
388          visiblepositionone.paintIcon(this, g10, 230, 370); 
389                      
390          Graphics g11 = (Graphics2D) g;
391          ImageIcon visiblepositiontwo = combos [secondrandom];
392          visiblepositiontwo.setImage(visiblepositiontwo.getImage().getScaledInstance(70, 90, 0));
393          visiblepositiontwo.paintIcon(this, g11, 420, 370); 
394                      
395          Graphics g12 = (Graphics2D) g;
396          ImageIcon visiblepositionthree = combos [thirdrandom];
397          visiblepositionthree.setImage(visiblepositionthree.getImage().getScaledInstance(70, 90, 0));
398          visiblepositionthree.paintIcon(this, g12, 610, 370);
399         
400       final JButton button1 = new JButton("Button 1");
401       JPanel buttonPanel = new JPanel();
402       GridLayout g20 = new GridLayout(3,1,10,10);
403       buttonPanel.setLayout(g20);
404       buttonPanel.add(button1);
405           
406      
407       buttonFrame.add(buttonPanel, BorderLayout.WEST);
408       buttonFrame.add(labelPanel, BorderLayout.EAST);
409       buttonFrame.add(new JButton("Woof"), BorderLayout.SOUTH);
410   
411       buttonFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
412       buttonFrame.setSize(900, 700);
413       buttonFrame.setVisible(true);
414      
415                    }
416                   
417            }
418      
419    //}
420
421    /*public static void main(String[] args)
422    {
423       final JButton button1 = new JButton("Mooooooooo....");
424       //final JButton button1 = new JButton("Button 1");
425       final JButton button2 = new JButton("Button 2");
426       button2.setPreferredSize(new Dimension(80,50));
427
428       final JButton button3 = new JButton("Button 3");
429       JPanel buttonPanel = new JPanel();
430       GridLayout g13 = new GridLayout(3,1,10,10);
431       buttonPanel.setLayout(g13);
432       buttonPanel.add(button1);
433       buttonPanel.add(button2);
434       buttonPanel.add(button3);
435
436     }*/
437
438
439 
