import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComponent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.Font;
import java.util.Random;
import java.util.Scanner;
import java.lang.Thread;
import java.lang.InterruptedException;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Font;

public class GUISlotsV3     // Class
{		
   int frameW, frameH;
   int chosenOption;
   int playerOption1;
   int playerOption2;
   int playerOption3;
   int playerOption4;
   ImageIcon[] combos;
   Random r = new Random();
   String payout = "Payout:";
   String s3 = "  ";
   String s4 = "  ";
   String bet = "Select Number of Credits to Play:";
   String balanceWord = "Credits: $";
   int balance = 100;
   String sBankrupt1 = "  ";
   String sBankrupt = "Bankrupt!";
   int values = 20;
   int gamblerCredits; 
   int combo = 0;
   boolean enough = false;
   boolean settingup = true; 
   boolean visible = false;
   ImageIcon firstimage;
   ImageIcon secondimage;
   ImageIcon thirdimage;
   int firstrandom = r.nextInt(18); // how to get a random image from the arrayList without a specific one
   int secondrandom = r.nextInt(18);
   int thirdrandom = r.nextInt(18); 
   private static JPanel labelPanel = new JPanel();
   private static JFrame buttonFrame = new JFrame("Button Frame");
   int wager = 0;
   int button2value = 2;
   int button3value = 5;
   int button4value = 10;
   int button5value = balance;
         
       public static void main(String[] args)
         {
         
         
         /*ImageIcon [] combos = new ImageIcon [20];
         combos [0] = new ImageIcon("watermelon.png");
         combos [1] = new ImageIcon("grapes.png");
         combos [2] = new ImageIcon("banana.png");
         combos [3] = new ImageIcon("cherry.png");
         combos [4] = new ImageIcon("lime.png");
         combos [5] = new ImageIcon("lemon.png");
         combos [6] = new ImageIcon("strawberry.png");
         combos [7] = new ImageIcon("orange.png");
         combos [8] = new ImageIcon("bells.png");
         combos [9] = new ImageIcon("wildcard.png");
                  
         combos [10] = new ImageIcon("numberone.png");
         combos [11] = new ImageIcon("numbertwo.png");
         combos [12] = new ImageIcon("numberthree.png");
         combos [13] = new ImageIcon("numberfour.png");
         combos [14] = new ImageIcon("numberfive.png");
         combos [15] = new ImageIcon("numbersix.png");
         combos [16] = new ImageIcon("numberseven.png");
         combos [17] = new ImageIcon("numbereight.png");
         combos [18] = new ImageIcon("numbernine.png");
         combos [19] = new ImageIcon ("nothing.jpg");*/

         
                  
            final JButton button1 = new JButton("Spin");
            button1.setPreferredSize(new Dimension(80,650));
            final JButton button2 = new JButton("Bet 2 Credits!");
            button2.setPreferredSize(new Dimension(80,650));
            final JButton button3 = new JButton("Button 5 Credits");
            button3.setPreferredSize(new Dimension(80,650));
            final JButton button4 = new JButton("Button 10 Credits");
            button4.setPreferredSize(new Dimension(80,650));
            final JButton button5 = new JButton("Bet it All");
            button5.setPreferredSize(new Dimension(80,650));
            final JButton button6 = new JButton("Rage Quit");
            button5.setPreferredSize(new Dimension(80,650));
            
            JPanel buttonPanel = new JPanel();
           buttonPanel.add(button1);
           buttonPanel.add(button2);
           buttonPanel.add(button3);
           buttonPanel.add(button4);
           buttonPanel.add(button5);
           buttonPanel.add(button6);
         /*
         while (settingup) 
         {
            
            //repaint();

            Object [] MainOpts = {"Play Slots", "Quit"};     //Main Menu
            chosenOption = JOptionPane.showOptionDialog(null, "Click an option", 
                 "Slots Options", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                  null, MainOpts, MainOpts[0]);
            
            if(chosenOption == 1)
            {
               break;
            }
           */ 
                        
         
            
     class AddButton1Listener implements ActionListener
      {
         public void actionPerformed(ActionEvent e)
         {
            
            for(int i = 1; i < 15; i++)
            {
                        try{Thread.sleep(30*i);}
                        catch(InterruptedException j) {}
                        firstrandom = r.nextInt(19) ; // how to get a random image from the arrayList without a specific one
                        secondrandom = r.nextInt(19);
                        thirdrandom = r.nextInt(19);
                        repaint();
                        
                        if ((firstrandom  == secondrandom) && (firstrandom == thirdrandom))
                          {
                                    balance += wager *3; 
                                             
                                       //case 2 : 
                                    if ((firstrandom  != secondrandom) && (firstrandom != thirdrandom))
                                          balance = balance - wager;
                                    
                                    if ((firstrandom  == secondrandom) || (firstrandom == thirdrandom))  
                                    {
                                    firstimage = combos[firstrandom];
                                    secondimage = combos[secondrandom];
                                    thirdimage = combos[thirdrandom];   
                                    }
                           }
               System.out.println(balance);

            }
         }
      }
               class AddButton2Listener implements ActionListener
               {
                  public void actionPerformed(ActionEvent e)
                  {
                     wager += button2value;
                  
                  }
               }
               class AddButton3Listener implements ActionListener
               {
                  public void actionPerformed(ActionEvent e)
                  {
                     wager += button3value;
                     
                  }
               }
         
              class AddButton4Listener implements ActionListener
               {
                  public void actionPerformed(ActionEvent e)
                  {
                     wager += button4value;
                     
                  }
               }
          
              class AddButton5Listener implements ActionListener
               {
                  public void actionPerformed(ActionEvent e)
                  {
                     wager += button5value;
                     
                  }
               }
                  
               class AddButton6Listener implements ActionListener
               {
                  public void actionPerformed(ActionEvent e)
                  {
                    
                   Object [] MainOpts = {"Are you sure?", "I lied!"};     //Main Menu
                   chosenOption = JOptionPane.showOptionDialog(null, "Click an option", 
                       "Quit Window", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                           null, MainOpts, MainOpts[0]);
                     
         
         
                     
                  }
               }
 
      ActionListener listener1 = new AddButton1Listener();
      button1.addActionListener(listener1);
      ActionListener listener2 = new AddButton2Listener();
      button2.addActionListener(listener2);
      ActionListener listener3 = new AddButton3Listener();
      button3.addActionListener(listener3);
      ActionListener listener4 = new AddButton4Listener();
      button4.addActionListener(listener4);
      ActionListener listener5 = new AddButton5Listener();
      button5.addActionListener(listener5);  
      ActionListener listener6 = new AddButton6Listener();
      button6.addActionListener(listener6);
                 
               
      /*JLabel label1 = new JLabel("Slot 1", combos[firstrandom],JLabel.CENTER);
      JLabel label2 = new JLabel("Slot 2", combos[secondrandom],JLabel.CENTER);
      JLabel label3 = new JLabel("Slot 3", combos[thirdrandom],JLabel.CENTER); 
      */
               
         }          
        
        
   public void paintComponent( Graphics g )    // Method: paintComponent
    {
      //background
      Graphics g2 = (Graphics2D) g;
      ImageIcon bg = new ImageIcon("slotsmachine - NEW.png");
      bg.setImage(bg.getImage().getScaledInstance(1000, 1000, 0));
      bg.paintIcon(this, g2, 0, -100);
      
      
      //End messages
      Graphics2D g13 = (Graphics2D) g;               //win message
      Font f1 = new Font ("serif", Font.BOLD, 70);
      g13.setColor(Color.WHITE);
      g13.setFont(f1);  
      g13.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT, 
                                           BasicStroke.JOIN_BEVEL));                                                                        
      g13.drawString(s3, 50,100);
      
      
      Graphics2D g14 = (Graphics2D) g;               //lose message
      g14.setColor(Color.WHITE);
      g14.setFont(f1);  
      g14.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT, 
                                           BasicStroke.JOIN_BEVEL));                                                                        
      g14.drawString(s4, 50,100);
      
      Font f3 = new Font ("serif", Font.BOLD, 30);
      Graphics2D g18 = (Graphics2D) g;               //Balance number message
      g18.setColor(Color.WHITE);
      g18.setFont(f3);  
      g18.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT, 
                                           BasicStroke.JOIN_BEVEL));                                                                        
      g18.drawString(Integer.toString(balance) , 170, 600);
      
      Graphics2D g19 = (Graphics2D) g;               //Balance word message
      g19.setColor(Color.WHITE);
      g19.setFont(f3);  
      g19.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT, 
                                           BasicStroke.JOIN_BEVEL));                                                                        
      g19.drawString(balanceWord , 30, 600);
      
                                                                     
      Graphics2D g21 = (Graphics2D) g;               //Bankrupt message
      g21.setColor(Color.GREEN);
      g21.setFont(f1);  
      g21.setStroke(new BasicStroke (10.0F, BasicStroke.CAP_BUTT, 
                                           BasicStroke.JOIN_BEVEL));                                                                        
      g21.drawString(sBankrupt1, 50, 200);
               
      Graphics g10 = (Graphics2D) g;
      ImageIcon visiblepositionone = combos [firstrandom];
      visiblepositionone.setImage(visiblepositionone.getImage().getScaledInstance(70, 90, 0));
      visiblepositionone.paintIcon(this, g10, 230, 370);  
                      
      Graphics g11 = (Graphics2D) g;
      ImageIcon visiblepositiontwo = combos [secondrandom];
      visiblepositiontwo.setImage(visiblepositiontwo.getImage().getScaledInstance(70, 90, 0));
      visiblepositiontwo.paintIcon(this, g11, 420, 370);  
                      
      Graphics g12 = (Graphics2D) g;
      ImageIcon visiblepositionthree = combos [thirdrandom];
      visiblepositionthree.setImage(visiblepositionthree.getImage().getScaledInstance(70, 90, 0));
      visiblepositionthree.paintIcon(this, g12, 610, 370);
         
      final JButton button1 = new JButton("Button 1"); 
      JPanel buttonPanel = new JPanel();
      GridLayout g20 = new GridLayout(3,1,10,10);
      buttonPanel.setLayout(g20);
      buttonPanel.add(button1);
           
      
  }
                   
}
