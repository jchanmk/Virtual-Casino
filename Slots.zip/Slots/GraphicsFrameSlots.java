import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.GridLayout;


public class GraphicsFrameSlots           // Class
{
  public static void main(String[] args) throws InterruptedException
   {
      int frameWidth = 1024;
      int frameHeight = 700;
      ImageIcon[] slots = new ImageIcon[20];

      JFrame frame = new JFrame();
      frame.setSize(frameWidth, frameHeight);
      frame.setTitle("Slots");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      ImageIcon numberOne = new ImageIcon("numberone.png"); 
      slots [0] = numberOne;
      ImageIcon numberTwo = new ImageIcon("numbertwo.png");
      slots [1] = numberTwo;
      ImageIcon numberThree = new ImageIcon("numberthree.png");
      slots [2] = numberThree;
      ImageIcon numberFour = new ImageIcon("numberfour.png");
      slots [3] = numberFour;
      ImageIcon numberFive = new ImageIcon("numberfive.png");
      slots [4] = numberFive;
      ImageIcon numberSix = new ImageIcon("numbersix.png");
      slots [5] = numberSix;
      ImageIcon numberSeven = new ImageIcon("numberseven.png");
      slots [6] = numberSeven;
      ImageIcon numberEight = new ImageIcon("numbereight.png");
      slots [7] = numberEight;   
      ImageIcon numberNine = new ImageIcon("numbernine.png");
      slots [8] = numberNine;
      ImageIcon banana = new ImageIcon("banana.png");
      slots [9] = banana;
      ImageIcon strawberry = new ImageIcon("strawberry.gif");
      slots [10] = strawberry;
      ImageIcon lemon = new ImageIcon("lemon.png");
      slots [11] = lemon;
      ImageIcon watermelon = new ImageIcon("watermelon.png");
      slots [12] = watermelon;
      ImageIcon lime = new ImageIcon("lime.png");
      slots [13] = lime;
      ImageIcon cherries = new ImageIcon("cherry.jpg");
      slots [14] = cherries;
      ImageIcon bells = new ImageIcon("bells.png");
      slots [15] = bells;
      ImageIcon blueberry = new ImageIcon("blueberry.jpeg");
      slots [16] = blueberry;
      ImageIcon orange = new ImageIcon("orange.png");
      slots [17] = orange;
      ImageIcon grapes = new ImageIcon("grapes.png");
      slots [18] = grapes;
      ImageIcon nothing = new ImageIcon("nothing.jpg");
      slots [19] = nothing;

      GraphicsComponentSlotsV2 gcs = 
         new GraphicsComponentSlotsV2 (frameWidth, frameHeight, slots);
      frame.add(gcs);
      frame.setVisible(true);
      
      final JButton button1 = new JButton("Spin");
      final JButton button2 = new JButton("Bet 2 Credits!");
      final JButton button3 = new JButton("Button 5 Credits");
      final JButton button4 = new JButton("Button 10 Credits");
      final JButton button5 = new JButton("Bet it All");
      JPanel buttonPanel = new JPanel();
      buttonPanel.add(button1);
      buttonPanel.add(button2);
      buttonPanel.add(button3);
      buttonPanel.add(button4);
      buttonPanel.add(button5);
      
      frame.add(buttonPanel);
      frame.setVisible(true);
      
      
      
      gcs.update();
      frame.dispose();
      
      
   
            /*JButton button = new JButton("OK");
      button.setPreferredSize(new Dimension(40,40));
      buttonPanel.add(button);
      buttonPanel.setMinimumSize(new java.awt.Dimension(150, 700));
      frame.setContentPane(buttonPanel); */
       
    }


}
